thank_you = function(x) {
  return('Thank you for your contribution to this class! I have truely learned a lot about R and am grateful for it!')
}
